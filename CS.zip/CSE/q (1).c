#include<stdio.h>
int main() 
{

  int naturalnumbers; 

  printf("The first 10 natural numbers are:\n ");

  for (naturalnumbers = 1; naturalnumbers <= 10; naturalnumbers++)
  
    printf("%d \t", naturalnumbers); 
	
}

